<?php
// Heading
$_['heading_title']    			= '<b>TG KingStore Pro Newsletter <a href="http://themeglobal.com/" style="color:#00badc;"> (Upgrage to Pro to use)</a></b>';

// Text
$_['text_module']      			= 'Modules';
$_['text_success']     			= 'Success: You have modified module TG KingStore Pro Newsletter!';
$_['text_edit']					= 'Edit Module TG KingStore Pro Newsletter';

// Entry
$_['entry_status']   			= 'Status'; 

// Error
$_['error_permission'] 			= 'Warning: You do not have permission to modify module TG KingStore Pro Newsletter!';