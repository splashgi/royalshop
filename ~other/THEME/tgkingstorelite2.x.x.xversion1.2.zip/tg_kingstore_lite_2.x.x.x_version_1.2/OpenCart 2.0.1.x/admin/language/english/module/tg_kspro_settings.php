<?php

// Heading Goes here:
$_['heading_title']    = '<b>TG KINGSTORE LITE SETTINGS</b>';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified module TG KingStore Lite Settings!';
$_['text_warning']     = 'Warning: Changes have not been saved! Make sure you have completed all fields well.';
$_['text_warning2']    = "Warning: Skin is not removed. Possible reasons:<br>- Skin doesn't exist<br> - Skin is active";

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module TG KingStore Lite Settings!';

?>
