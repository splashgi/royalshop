<?php

// Heading
$_['heading_title']    = '<b>TG KingStore Lite Revolution Slider</b>';

// Text
$_['text_success']     = 'Success: You have modified module TG KingStore Lite Revolution Slider!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module TG KingStore Lite Revolution Slider!';

?>