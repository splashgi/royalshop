<?php

// Heading Goes here:
$_['heading_title']    = '<b>TG KingStore Pro MegaMenu Vertical<a href="http://themeglobal.com/" style="color:#00badc;"> (Upgrage to Pro to use)</a></b>';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified module TG KingStore Pro MegaMenu Vertical!';
$_['text_warning']     = 'Warning: Changes have not been saved! Make sure you have completed all fields well.';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module TG KingStore Pro MegaMenu Vertical!';

?>
